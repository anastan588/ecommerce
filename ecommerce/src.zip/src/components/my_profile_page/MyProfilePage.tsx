import React from 'react';

const MyProfilePage = () => {
    return <h2 className="page_title main">My Profile Page</h2>;
};

export default MyProfilePage;
