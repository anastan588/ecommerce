import React from 'react';

const CatalogPage = () => {
    return <h2 className="page_title main">Catalog page</h2>;
};

export default CatalogPage;
