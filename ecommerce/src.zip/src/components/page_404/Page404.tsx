import React from 'react';

const Page404 = () => {
    return <h2 className="page_title main">404 Page not found</h2>;
};

export default Page404;
