import React from 'react';

const AboutUsPage = () => {
    return <h2 className="page_title main">About us page</h2>;
};

export default AboutUsPage;
