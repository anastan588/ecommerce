import React from 'react';

const MainPage = () => {
    return <h2 className="page_title main">Main page</h2>;
};

export default MainPage;
