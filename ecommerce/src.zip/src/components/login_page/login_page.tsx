import React from 'react';

const LogInPage = () => {
    return <h2>Log In Page</h2>;
};

export default LogInPage;
