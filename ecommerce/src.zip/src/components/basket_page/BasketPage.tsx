import React from 'react';

const BasketPage = () => {
    return <h2 className="page_title main">Basket page</h2>;
};

export default BasketPage;
